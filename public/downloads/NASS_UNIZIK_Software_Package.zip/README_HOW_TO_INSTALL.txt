NASS UNIZIK DEPARTMENTAL MOBILE APPLICATION & OFFLINE SOFTWARE
Department of Statistics • Nnamdi Azikiwe University (UNIZIK), Awka
Faculty of Physical Sciences

========================================================================
HOW TO RUN ON YOUR DEVICE (ANDROID, iOS, WINDOWS, MAC, LINUX)
========================================================================

1. ON ANDROID:
   - Extract this folder on your phone.
   - Tap 'index.html' to open in Chrome, Samsung Internet, or Opera.
   - You can tap 'Add to Home screen' in Chrome to place the NASS icon on your home screen.
   - All 14MB+ of lecture notes, past questions, and statistical tables will open instantly offline!
   - NO "problem in parsing the package" error because it runs directly on Android without APK parsing conflicts!

2. ON iPHONE / iPAD (iOS):
   - AirDrop or open this folder on your Apple device.
   - Tap 'NASS_UNIZIK.mobileconfig' to install the official UNIZIK WebClip profile to your home screen!
   - Or open 'index.html' in Safari, tap the Share button (square with arrow), and tap 'Add to Home Screen'.

3. ON PC / LAPTOP (WINDOWS, MAC, LINUX):
   - Simply double click 'index.html' to launch the portal.

========================================================================
INCLUDED MATERIALS (14MB+ BUNDLE):
- STA 312 Bivariate Distributions & Mathematical Proofs
- STA 312 Order Statistics Part 1, 2, 3
- STA 322 Complete Course Material
- STA 331 Regression Analysis Compendium
- STA 371 Operations Research (Dr. Ikediuwa, 3.8MB)
- COS 201 C++ Programming Notes
- CSC 202 Course Material & Practice Module
- ENT 312 Entrepreneurship Master Notes (Chapters 1-15)
- GST 312 Peace & Conflict Resolution CBT Study Guide
- Schaum's Outline Statistics & Solved Problems
- Official Statistical Tables (Z, t, F, Chi-Square)
- Departmental SQLite Database (nass_portal.db)
- Apple iOS Profile (NASS_UNIZIK.mobileconfig)
========================================================================
Designed by NASS UNIZIK • Powered by PhanCore
